from __future__ import annotations

from .cli_main import main


if __name__ == "__main__":
    main()
